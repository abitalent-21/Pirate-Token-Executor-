package com.carter.piratetoken

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlin.math.pow

private val Ink = Color(0xFF10151B)
private val Panel = Color(0xFF1C2731)
private val Panel2 = Color(0xFF263541)
private val Gold = Color(0xFFFFC857)
private val Crimson = Color(0xFFB8323E)
private val Muted = Color(0xFFB7C0C8)
private const val BASE_ODDS = 137500.0

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PirateApp() }
    }
}

private data class Zone(val name: String, val detail: String, val x: Float, val y: Float)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PirateApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pirate_tracker", Context.MODE_PRIVATE) }
    var chestCount by rememberSaveable { mutableIntStateOf(prefs.getInt("chests", 0)) }
    var found by rememberSaveable { mutableStateOf(prefs.getBoolean("found", false)) }
    var treasureHour by rememberSaveable { mutableStateOf(prefs.getBoolean("treasure_hour", false)) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedZone by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addAmount by remember { mutableStateOf("1") }

    fun persist() {
        prefs.edit().putInt("chests", chestCount).putBoolean("found", found)
            .putBoolean("treasure_hour", treasureHour).apply()
    }

    val zones = listOf(
        Zone("North coast", "Search route idea • open every chest you encounter", .24f, .23f),
        Zone("Harbor district", "Search route idea • prioritize dense chest clusters", .72f, .30f),
        Zone("Central ruins", "Search route idea • sweep buildings and nearby cover", .48f, .54f),
        Zone("South cove", "Search route idea • check shoreline structures", .25f, .79f),
        Zone("Eastern outpost", "Search route idea • clear the area before rotating", .78f, .76f)
    )

    val probability = if (chestCount <= 0) 0.0 else
        1.0 - (1.0 - 1.0 / (BASE_ODDS / if (treasureHour) 1.5 else 1.0)).pow(chestCount)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, secondary = Crimson, background = Ink,
            surface = Panel, onPrimary = Ink, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("☠ PIRATE TOKEN", fontWeight = FontWeight.Black, color = Gold, fontSize = 19.sp)
                            Text("FORTNITE CHEST HUNT TRACKER", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Finder") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Map, null) }, label = { Text("Map") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Timeline, null) }, label = { Text("Progress") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Info") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> FinderScreen(
                    padding, chestCount, found, treasureHour, probability,
                    onAdd = { chestCount += it; persist() },
                    onFound = { found = it; persist() },
                    onTreasureHour = { treasureHour = it; persist() },
                    onMap = { tab = 1 }
                )
                1 -> MapScreen(padding, zones, selectedZone, { selectedZone = it })
                2 -> ProgressScreen(padding, chestCount, probability, found,
                    onAdd = { chestCount += it; persist() },
                    onReset = { chestCount = 0; found = false; persist() })
                else -> InfoScreen(padding)
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add opened chests") },
            text = {
                OutlinedTextField(
                    value = addAmount, onValueChange = { addAmount = it.filter(Char::isDigit).take(6) },
                    label = { Text("Number of chests") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    chestCount += (addAmount.toIntOrNull() ?: 0).coerceAtLeast(0)
                    persist(); showAdd = false
                }) { Text("ADD", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("CANCEL") } },
            containerColor = Panel
        )
    }
}

@Composable
private fun FinderScreen(
    padding: PaddingValues, chests: Int, found: Boolean, treasureHour: Boolean,
    probability: Double, onAdd: (Int) -> Unit, onFound: (Boolean) -> Unit,
    onTreasureHour: (Boolean) -> Unit, onMap: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2020))) {
                Column(Modifier.padding(16.dp)) {
                    Text("IMPORTANT: THERE IS NO EXACT TOKEN PIN", color = Gold, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "The Pirate Shop Access reward is a random chest drop, not a collectible sitting at a fixed map location. This app helps you plan chest-search routes and track your attempts; it cannot predict which chest will award it.",
                        color = Color.White, fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("YOUR HUNT", color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(if (found) "TOKEN FOUND!" else "$chests CHESTS OPENED", color = Gold, fontSize = 31.sp, fontWeight = FontWeight.Black)
                    Text(if (found) "Congratulations — mark your in-game reward as collected." else "Estimated chance of at least one drop", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { probability.toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(9.dp),
                        color = Gold, trackColor = Panel2
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(String.format("%.4f%% cumulative probability (model estimate)", probability * 100), color = Gold, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onAdd(1) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("CHEST OPENED")
                }
                OutlinedButton(onClick = onMap, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Map, null); Spacer(Modifier.width(5.dp)); Text("VIEW MAP")
                }
            }
        }
        item {
            OutlinedButton(onClick = { onTreasureHour(!treasureHour) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (treasureHour) "TREASURE HOUR MODEL: ON" else "TREASURE HOUR MODEL: OFF", color = Gold)
            }
            Text("Only enable this when the in-game event is active. The multiplier is an estimate based on reported event information, not a live Epic feed.", color = Muted, fontSize = 11.sp)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = found, onCheckedChange = onFound, colors = CheckboxDefaults.colors(checkedColor = Gold))
                Text("I found the Pirate Shop Access token in-game", color = Color.White, fontSize = 13.sp)
            }
        }
        item {
            Text("HOW TO HUNT", color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("1. Enter the correct Fortnite Treasure Hunters Battle Royale mode.\n2. Follow a chest-search route on the map tab.\n3. Open chests; each opening is a separate random roll.\n4. Tap CHEST OPENED to keep your count.\n5. Verify any reward in Fortnite itself.", color = Muted, lineHeight = 21.sp, fontSize = 13.sp)
        }
    }
}

@Composable
private fun MapScreen(padding: PaddingValues, zones: List<Zone>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CHEST SEARCH ROUTE MAP", color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text("Conceptual route planner — not the official Fortnite island map and not verified chest coordinates.", color = Muted, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172A2B)), shape = RoundedCornerShape(20.dp)) {
            Box(Modifier.fillMaxWidth().height(310.dp).padding(8.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height
                    drawRect(Color(0xFF17434A))
                    val island = Path().apply {
                        moveTo(w*.12f,h*.26f); lineTo(w*.30f,h*.10f); lineTo(w*.55f,h*.12f)
                        lineTo(w*.82f,h*.24f); lineTo(w*.91f,h*.48f); lineTo(w*.77f,h*.78f)
                        lineTo(w*.53f,h*.91f); lineTo(w*.25f,h*.83f); lineTo(w*.09f,h*.57f); close()
                    }
                    drawPath(island, Color(0xFF75804A))
                    drawCircle(Color(0xFF9A9A5A), w*.10f, Offset(w*.49f,h*.48f))
                    drawCircle(Color(0xFF536F45), w*.055f, Offset(w*.27f,h*.29f))
                    drawCircle(Color(0xFF536F45), w*.07f, Offset(w*.72f,h*.32f))
                    drawCircle(Color(0xFF536F45), w*.06f, Offset(w*.28f,h*.73f))
                    drawCircle(Color(0xFF536F45), w*.07f, Offset(w*.74f,h*.72f))
                    zones.forEachIndexed { i, z ->
                        val c = if (i == selected) Gold else Crimson
                        drawCircle(c, if (i == selected) 17f else 12f, Offset(w*z.x,h*z.y))
                        drawCircle(Color.White, 4f, Offset(w*z.x,h*z.y))
                    }
                }
                zones.forEachIndexed { i, z ->
                    Box(Modifier.fillMaxSize()) {
                        Box(Modifier.offset(x=(z.x*290).dp, y=(z.y*270).dp).size(34.dp)
                            .clickable { onSelect(i) })
                    }
                }
                Text("N", Modifier.align(Alignment.TopCenter).padding(8.dp), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Text("SELECT A SEARCH ZONE", color = Gold, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(zones.size) { index ->
                val z = zones[index]
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(index) },
                    colors = CardDefaults.cardColors(containerColor = if (index == selected) Color(0xFF49391D) else Panel)
                ) {
                    Column(Modifier.padding(13.dp)) {
                        Text("${index+1}. ${z.name}", color = Gold, fontWeight = FontWeight.Bold)
                        Text(z.detail, color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(padding: PaddingValues, chests: Int, probability: Double, found: Boolean, onAdd: (Int) -> Unit, onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("HUNT PROGRESS", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
        StatCard("Chests recorded", chests.toString())
        StatCard("Modelled cumulative chance", String.format("%.4f%%", probability*100))
        StatCard("Reward status", if (found) "Marked found" else "Not marked found")
        Button(onClick = { onAdd(10) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
            Text("+10 CHESTS")
        }
        OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("RESET TRACKER")
        }
        Text("Probability assumes independent chest rolls at the stated base rate. It is not a prediction or a guarantee, and event rates may differ.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 12.sp)
            Text(value, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoScreen(padding: PaddingValues) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("ABOUT & SOURCES", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Why the finder works differently", color = Gold, fontWeight = FontWeight.Bold)
                    Text("The Pirate Shop Access token is a random chest reward. No third-party app can see or predict the result of an unopened chest. This app does not connect to Epic accounts, inspect Fortnite memory, or automate gameplay.", color = Color.White, fontSize = 13.sp)
                    Text("Reported base odds: 1 in 137,500 per chest. Verify current event rates and availability in Fortnite.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { Text("READ MORE", color = Gold, fontWeight = FontWeight.Bold) }
        item {
            Text("VGC — Epic confirms Pirate Shop Access drop rate (9 Nov 2026)", color = Color(0xFF8FC7FF), fontSize = 13.sp)
        }
        item {
            Text("Beebom — Fortnite Treasure Hours tracker (22 Nov 2026)", color = Color(0xFF8FC7FF), fontSize = 13.sp)
        }
        item {
            Text("Unofficial fan-made companion. Not affiliated with, endorsed by, or sponsored by Epic Games. Fortnite is a trademark of Epic Games, Inc.", color = Muted, fontSize = 11.sp)
        }
    }
}
