# CART3R Pirate Token Finder

An offline Android companion for Samsung Galaxy A56 and other Android devices.

## What it does
- Tracks the number of Fortnite chests you have opened.
- Estimates cumulative chance from the reported base drop rate (1 in 137,500 per chest).
- Lets you manually mark the Pirate Shop Access token as found.
- Includes a conceptual chest-search route map and selectable search zones.
- Persists progress locally with Android SharedPreferences.
- Includes an optional Treasure Hour model toggle (clearly marked as an estimate).

## Important accuracy note
The Pirate Shop Access reward is a random chest reward, not a fixed collectible with a known map coordinate. No third-party app can identify which unopened chest will award it. The map in this app is a route-planning concept, not an official Fortnite map or verified chest-location database. Do not treat its zone markers as token locations.

The base odds and event context are based on reporting available on 23 November 2026:
- VGC, 9 Nov 2026: https://www.videogameschronicle.com/news/fortnite-officially-confirms-pirate-shop-token-drop-rate-as-players-hunt-for-item-which-makes-entire-shop-free/
- Beebom, 22 Nov 2026: https://beebom.com/fortnite-treasure-hour-event-guide/

The Treasure Hour toggle is a user-controlled estimate; verify event modifiers in-game. The tracker does not receive live Epic Games data.

## Build
1. Install Android Studio (a recent stable release) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync. Use JDK 17.
4. Connect your Galaxy A56 with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK.

## Technical
- Kotlin
- Jetpack Compose + Material 3
- minSdk 26 / targetSdk 35
- No account login, network permission, API key, or third-party SDK required.
